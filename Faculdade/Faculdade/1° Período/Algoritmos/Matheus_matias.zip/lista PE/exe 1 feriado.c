#include<stdio.h> //de inicio tentei fazer sem usar vetor, mas não consegui.
int main(){ //Ai como ñ pensei em nenhuma solução, deixei até ler os valores. Ñ consegui desenvolver...
    
    int soma=0, i=0;
    int x;
    int vet[12];
    
    while(x>=0){
        for(i=0; i<12; i++){
            scanf("%d", &vet[i]);
            soma=soma+vet[i]; 


        }
        
        
        
    }
    printf("a media e = %d" , vet[10,20]/10);

    return 0;

}